#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int Fun(int s[], int n)
{
	int max = s[0], i, no = 0;
	for (i = 1; i < n; i++)
	{
		if (s[i]>max)
		{
			no = i;
			max = s[i];
		}
	}
	return no;
}
void main()
{
	int a[10] = { 876, 675, 896, 101, 301, 401, 980, 431, 451, 777 }, k;
	k = Fun(a, 10);
	printf("%d, %d\n ", k + 1, a[k]);
}
