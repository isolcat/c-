#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
void main()
{
	float Fun(int n);
	int n;
	float s;
	printf("\nPlease enter N:");
	scanf("%d", &n);
	s = Fun(n);
	printf("The result is %f\n", s);
}
float Fun(int n)
{
	float m = 0; float s = 0;
	for (int i = 1; i <= n; i++)
	{
		m += i;
		s += (1 / m);
	}
	return s;
}