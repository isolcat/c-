#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#define PI 3.14159
main()
{
	double r;
	printf("Input r:");
	scanf("%lf", &r);
	printf("area=%.10f\n", PI*r*r);
	printf("superficial area=%.10f\n", 4 * PI*r*r);
	printf("volum=%.10f\n", 4 / 3 * PI*r*r*r);
	return 0;
}