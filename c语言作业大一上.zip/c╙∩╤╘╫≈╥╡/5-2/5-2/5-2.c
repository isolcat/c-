#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int main()
{
	int score[5][6] = { { 1, 2, 3, 4, 5, 6 }, { 7, 8, 9, 10, 11, 12 }, { 13, 14, 15, 16, 17, 18 }, { 19, 20, 21, 22, 23, 24 }, { 25, 26, 27, 28, 29, 30 } };
	int  b[6][5], i, j;
	for (i = 0; i < 5; i++)
	{
		for (j = 0; j < 6; j++)
		{
			printf("%-5d", score[i][j]);
			b[j][i] = score[i][j];
		}
		printf("\n");
	}
	printf("\n");
	for (j = 0; j < 6; j++)
	{
		for (i = 0; i < 5; i++)
			printf("%-5d", b[j][i]);
		printf("\n");
	}
	printf("\n");
}