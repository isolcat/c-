#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int main()
{
	printf(" x | x | x  \n---+---+---\n   |   |\n---+---+---\n 0 | 0 | 0\n");
	return 0;
}