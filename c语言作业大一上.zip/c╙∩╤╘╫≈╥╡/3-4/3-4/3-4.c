#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int main()
{
	int a, b, c;
	int i;
	for (i = 100; i < 999; i++)
	{
		a = i / 100;
		b = (i - a * 100) / 10;
		c = i - a * 100 - b * 10;
		if (a*a*a + b*b*b + c*c*c == i)
			printf("%d\t", i);
	}
	return 0;

}