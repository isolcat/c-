#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int main()
{
	int s = 0, a, n, t;
	printf("������a��n��ֵ��\n");
	scanf("%d %d", &a, &n);
	t = a;
	while (n > 0)
	{
		s += t;
		a = a * 10;
		t += a;
		n--;
	}
	printf("a+a+....=%d\n", s);
	return 0;
}