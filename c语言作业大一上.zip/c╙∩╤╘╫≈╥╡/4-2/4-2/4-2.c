#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int main()
{
	int score[100];
	int i;
	int j;
	printf("������10������:\n");
	for (i = 0; i < 10; i++)
	{
		scanf("%d", &score[i]);
	}
	for (j = 9; j>1; j--)
	{
		printf("%-5d", score[j]);
	}
	return 0;
}