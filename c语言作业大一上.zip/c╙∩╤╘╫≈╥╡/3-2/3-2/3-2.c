#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int main()
{
	int i, sum = 0;
	for (i = 1; i<100; i += 2)
	{
		sum += i*(i + 1);
	}
	printf("%d\n", sum);

	return 0;
}