#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#define N 80
int Fun(char *str)
{
	int i, n = 0, flag = 1;
	char*p = str;
	while (*p)
	{
		n++;
		p++;
	}
	for (i = 0; i<n / 2; i++)
	if (str[i] == str[n - 1 - i]);
	else
	{
		flag = 0;
		break;
	}
	return flag;
}
main()
{
	char s[N];
	char *test[] = { "1234321", "123421", "123321", "abcdCBA" };
	int i;
	printf("Enter a string : ");
	gets(s);
	printf("\n\n");
	puts(s);
	if (Fun(s))
		printf("YES\n");
	else
		printf("NO\n");
	//����
	for (i = 0; i<4; i++)
	if (Fun(test[i]))
		printf("YES\n");
	else
		printf("NO\n");
	// ���Խ���
}