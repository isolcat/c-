#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int main()
{
	int n, i, flag = 1;
	printf("������һ������:");
	scanf("%d", &n);
	for (i = 2; i < n / 2; i++)
	if (n%i == 0)
	{
		flag = 0;
		break;
	}
	if (flag == 1)
		printf("1\n");
	else
		printf("0\n");
	return 0;
}