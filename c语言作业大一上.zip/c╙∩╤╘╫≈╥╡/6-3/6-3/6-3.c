#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<string.h>
int main()
{
	char a[5][1000], t[1000];
	int i, k;
	printf("��������λͬѧ�����֣�\n");
	for (i = 0; i<5; i++)
	{
		scanf("%s", a[i]);
	}
	for (i = 1; i<5; i++){
		if (strcmp(a[0], a[i]) == 1)
		{
			strcpy(a[0], a[i]);
		}
	}
	printf("%s\n", a[0]);
	return 0;
}